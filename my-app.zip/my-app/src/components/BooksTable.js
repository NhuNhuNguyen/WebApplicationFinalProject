// src/components/BooksTable.js
import React from 'react';
import './BooksTable.css';

const BooksTable = ({ books }) => {
    return (
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Genre</th>
                    <th>Year</th>
                    <th>Availability</th>
                    <th>Other Information</th>
                </tr>
            </thead>
            <tbody>
                {books.map((book, index) => (
                    <tr key={index}>
                        <td>{book.title}</td>
                        <td>{book.author_name ? book.author_name.join(', ') : 'N/A'}</td>
                        <td>{book.genre ? book.genre.join(', ') : 'N/A'}</td>
                        <td>{book.publish_year ? book.publish_year.join(', ') : 'N/A'}</td>
                        <td>{book.availability ? 'Available' : 'Not Available'}</td>
                        <td>
                            {/* Display additional information from the API here */}
                            {/* Example: book.publisher, book.language, etc. */}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default BooksTable;


