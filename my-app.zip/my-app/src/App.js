// src/App.js
import React, { useState, useEffect } from 'react';
import BooksTable from './components/BooksTable';

const App = () => {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    // Fetch data when the component mounts or when the query changes
    if (query) {
      fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
          setBooks(data.docs); // Assuming search results are in data.docs
        })
        .catch(error => console.error("Error fetching data:", error));
    }
  }, [query]);

  const handleSearch = (event) => {
    event.preventDefault();
    // The search query state is already being used in the useEffect hook
  };

  return (
    <div className="App">
      <h1>Library Catalog</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Search for books"
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>
      <BooksTable books={books} />
    </div>
  );
};

export default App;

